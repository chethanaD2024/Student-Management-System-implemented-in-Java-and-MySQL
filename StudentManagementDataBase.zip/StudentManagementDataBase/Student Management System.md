**Student Management System**



A comprehensive Java-based Student Management System that allows users to perform CRUD (Create, Read, Update, Delete) operations on student records through a console-based interface.



**Features**



\- Add New Students: Complete student information with multiple courses

\- View All Students: Display all records in a formatted table

\- Search Students: Find students by their unique ID

\- Update Student Information: Modify existing student records

\- Delete Students: Remove student records from the system

\- MySQL Database Integration: Persistent data storage



**Database Schema**



The system uses a MySQL database with the following table structure:



```sql

CREATE TABLE students (

&nbsp;   id INT PRIMARY KEY AUTO\_INCREMENT,

&nbsp;   name VARCHAR(50) NOT NULL,

&nbsp;   age INT NOT NULL,

&nbsp;   email VARCHAR(50),

&nbsp;   gender VARCHAR(10),

&nbsp;   contact\_number VARCHAR(15),

&nbsp;   course1 VARCHAR(50),

&nbsp;   course2 VARCHAR(50),

&nbsp;   course3 VARCHAR(50)

);

```



**Prerequisites**



Before running this application, ensure you have:



\- Java JDK 8 or higher

\- MySQL Server installed and running

\- MySQL Connector/J\*\* (JDBC driver) in your classpath



**Installation \& Setup**



1\. Create the database:

&nbsp;  ```sql

&nbsp;  CREATE DATABASE studentdb;

&nbsp;  USE studentdb;

&nbsp;  ```



2\. Create the students table:

&nbsp;  ```sql

&nbsp;  CREATE TABLE students (

&nbsp;      id INT PRIMARY KEY AUTO\_INCREMENT,

&nbsp;      name VARCHAR(50) NOT NULL,

&nbsp;      age INT NOT NULL,

&nbsp;      email VARCHAR(50),

&nbsp;      gender VARCHAR(10),

&nbsp;      contact\_number VARCHAR(15),

&nbsp;      course1 VARCHAR(50),

&nbsp;      course2 VARCHAR(50),

&nbsp;      course3 VARCHAR(50)

&nbsp;  );

&nbsp;  ```



3\. Update database credentials:

&nbsp;  Modify the `DBConnection.java` file with your MySQL credentials:

&nbsp;  ```java

&nbsp;  connection = DriverManager.getConnection(

&nbsp;      "jdbc:mysql://localhost:3306/studentdb", "your\_username", "your\_password");

&nbsp;  ```



4\. Add MySQL connector to classpath:

&nbsp;  - Download MySQL Connector/J

&nbsp;  - Add the JAR file to your project's build path



**How to Run**



1\. Compile all Java files:

&nbsp;  ```bash

&nbsp;  javac -cp .:mysql-connector-java-8.0.23.jar \*.java

&nbsp;  ```



2\. Run the application:

&nbsp;  ```bash

&nbsp;  java -cp .:mysql-connector-java-8.0.23.jar Main

&nbsp;  ```



**Usage**



**Main Menu Options**:

```

===== Student Management System =====

1\. Add Student

2\. Show All Students

3\. Get Student by ID

4\. Update Student

5\. Delete Student

6\. Exit

```



**Adding a Student:**

\- Name (required)

\- Age (required)

\- Email

\- Gender

\- Contact Number

\- Course 1

\- Course 2

\- Course 3



**Viewing Students:**

Students are displayed in a formatted table with columns:

\- ID, Name, Age, Email, Gender, Contact Number, and Courses



**Project Structure**



```

StudentManagementSystem/

├── Main.java              # Main application class with menu system

├── Student.java           # Student entity class with getters/setters

├── StudentDAO.java        # Data Access Object for database operations

├── DBConnection.java      # Database connection utility class

└── README.md             # This file

```



**Class Responsibilities**



\- Main            : Handles user input and menu navigation

\- Student        : Data model representing a student with all attributes

\- StudentDAO: Contains all database operations (CRUD methods)

\- DBConnection : Manages database connection and provides connection instances



**Technologies Used**



\- Java SE    - Core programming language

\- MySQL     - Database management system

\- JDBC        - Java Database Connectivity for MySQL integration

\- Java Scanner - For console input handling



**Error Handling**



The system includes comprehensive error handling for:

\- Database connection failures

\- SQL syntax errors

\- Input validation issues

\- Data type mismatches

\- Record not found scenarios



**Future Enhancements**



Potential improvements for this system:

\- Input validation and sanitization

\- GUI interface using JavaFX or Swing

\- Course management system

\- Grade tracking functionality

\- Search and filter capabilities

\- Data export features

\- User authentication system



**Troubleshooting**



Common issues and solutions:



1\. Database connection failed: Check MySQL service status and credentials

2\. Table doesn't exist: Verify the database and table creation SQL

3\. Driver not found: Ensure MySQL Connector/J is in the classpath

4\. Input mismatch errors: Follow the exact input format prompts



Note: Remember to replace the database credentials in `DBConnection.java` with your actual MySQL username and password before running the application.



**Created by:**

A.D.D.C. Wijethunge

16562

IT3003


import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentDAO dao = new StudentDAO();
        int choice;

        do {
            System.out.println("\n===== Student Management System =====");
            System.out.println("1. Add Student");
            System.out.println("2. Show All Students");
            System.out.println("3. Get Student by ID");
            System.out.println("4. Update Student");
            System.out.println("5. Delete Student");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = sc.nextInt();
            sc.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();
                    System.out.print("Enter age: ");
                    int age = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Enter email: ");
                    String email = sc.nextLine();
                    System.out.print("Enter gender: ");
                    String gender = sc.nextLine();
                    System.out.print("Enter contact number: ");
                    String contactNumber = sc.nextLine();
                    System.out.print("Enter course 1: ");
                    String course1 = sc.nextLine();
                    System.out.print("Enter course 2: ");
                    String course2 = sc.nextLine();
                    System.out.print("Enter course 3: ");
                    String course3 = sc.nextLine();

                    dao.addStudent(new Student(name, age, email, gender, contactNumber, course1, course2, course3));
                    break;

                case 2:
                    List<Student> students = dao.getAllStudents();
                    if (students.isEmpty()) {
                        System.out.println("No students found.");
                    } else {
                        System.out.printf("%-4s %-15s %-4s %-25s %-8s %-15s %-30s%n",
                                "ID", "Name", "Age", "Email", "Gender", "Contact", "Courses");
                        System.out.println("-------------------------------------------------------------------------------------------");

                        for (Student s1 : students) {
                            String courses = s1.getCourse1() + ", " + s1.getCourse2() + ", " + s1.getCourse3();
                            System.out.printf("%-4d %-15s %-4d %-25s %-8s %-15s %-30s%n",
                                    s1.getId(),
                                    s1.getName(),
                                    s1.getAge(),
                                    s1.getEmail(),
                                    s1.getGender(),
                                    s1.getContactNumber(),
                                    courses);
                        }
                    }
                    break;

                case 3:
                    System.out.print("Enter student ID: ");
                    int id = sc.nextInt();
                    sc.nextLine();
                    Student s = dao.getStudentById(id);
                    if (s != null) {
                        // Print table header
                        System.out.printf("%-4s %-15s %-4s %-25s %-8s %-15s %-30s%n",
                                "ID", "Name", "Age", "Email", "Gender", "Contact", "Courses"); // Changed "Subjects" to "Courses"
                        System.out.println("-------------------------------------------------------------------------------------------");

                        // Print student data
                        String courses = s.getCourse1() + ", " + s.getCourse2() + ", " + s.getCourse3();
                        System.out.printf("%-4d %-15s %-4d %-25s %-8s %-15s %-30s%n",
                                s.getId(),
                                s.getName(),
                                s.getAge(),
                                s.getEmail(),
                                s.getGender(),
                                s.getContactNumber(),
                                courses);

                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 4:
                    System.out.print("Enter student ID to update: ");
                    int updateId = sc.nextInt();
                    sc.nextLine(); // Consume the newline left by nextInt()

                    Student existing = dao.getStudentById(updateId);
                    if (existing != null) {
                        System.out.print("Enter new name: ");
                        String newName = sc.nextLine();
                        System.out.print("Enter new age: ");
                        int newAge = sc.nextInt();
                        sc.nextLine(); // Consume the newline left by nextInt()
                        System.out.print("Enter new email: ");
                        String newEmail = sc.nextLine();
                        System.out.print("Enter new gender: ");
                        String newGender = sc.nextLine();
                        System.out.print("Enter new contact number: ");
                        String newContact = sc.nextLine();
                        System.out.print("Enter new course 1: ");
                        String newCourse1 = sc.nextLine();
                        System.out.print("Enter new course 2: ");
                        String newCourse2 = sc.nextLine();
                        System.out.print("Enter new course 3: ");
                        String newCourse3 = sc.nextLine();

                        existing.setName(newName);
                        existing.setAge(newAge);
                        existing.setEmail(newEmail);
                        existing.setGender(newGender);
                        existing.setContactNumber(newContact);
                        existing.setCourse1(newCourse1);
                        existing.setCourse2(newCourse2);
                        existing.setCourse3(newCourse3);

                        dao.updateStudent(existing);

                        // Print updated student in table format
                        System.out.println("\nUpdated Student:");
                        System.out.printf("%-4s %-15s %-4s %-25s %-8s %-15s %-30s%n",
                                "ID", "Name", "Age", "Email", "Gender", "Contact", "Courses");
                        System.out.println("-------------------------------------------------------------------------------------------");
                        String courses = existing.getCourse1() + ", " + existing.getCourse2() + ", " + existing.getCourse3();
                        System.out.printf("%-4d %-15s %-4d %-25s %-8s %-15s %-30s%n",
                                existing.getId(),
                                existing.getName(),
                                existing.getAge(),
                                existing.getEmail(),
                                existing.getGender(),
                                existing.getContactNumber(),
                                courses);
                    } else {
                        System.out.println("Student not found.");
                    }
                    break;

                case 5:
                    System.out.print("Enter student ID to delete: ");
                    int deleteId = sc.nextInt();
                    sc.nextLine(); // Consume newline
                    dao.deleteStudent(deleteId);
                    break;

                case 6:
                    System.out.println("Exiting...");
                    break;

                default:
                    System.out.println("Invalid choice! Try again.");
            }

        } while (choice != 6);

        sc.close();
    }
}
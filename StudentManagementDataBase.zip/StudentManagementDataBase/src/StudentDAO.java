import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class StudentDAO {

    // Add a new student
    public void addStudent(Student student) {
        String sql = "INSERT INTO students (name, age, email, gender, contact_number, course1, course2, course3) VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getName());
            pstmt.setInt(2, student.getAge());
            pstmt.setString(3, student.getEmail());
            pstmt.setString(4, student.getGender());
            pstmt.setString(5, student.getContactNumber());
            pstmt.setString(6, student.getCourse1());
            pstmt.setString(7, student.getCourse2());
            pstmt.setString(8, student.getCourse3());

            pstmt.executeUpdate();
            System.out.println("Student added successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Get all students(correct parameter order)
    public List<Student> getAllStudents() {
        List<Student> students = new ArrayList<>();
        String sql = "SELECT * FROM students";
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                students.add(new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("email"),        // email should come before gender
                        rs.getString("gender"),       // gender after email
                        rs.getString("contact_number"),
                        rs.getString("course1"),
                        rs.getString("course2"),
                        rs.getString("course3")
                ));
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return students;
    }

    // Get student by ID (correct parameter order)
    public Student getStudentById(int id) {
        String sql = "SELECT * FROM students WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new Student(
                        rs.getInt("id"),
                        rs.getString("name"),
                        rs.getInt("age"),
                        rs.getString("email"),        // email should come before gender
                        rs.getString("gender"),       // gender after email
                        rs.getString("contact_number"),
                        rs.getString("course1"),
                        rs.getString("course2"),
                        rs.getString("course3")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null; // student not found
    }

    // Update student (correct parameter order and count)
    public void updateStudent(Student student) {
        String sql = "UPDATE students SET name=?, age=?, email=?, gender=?, contact_number=?, course1=?, course2=?, course3=? WHERE id=?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setString(1, student.getName());
            pstmt.setInt(2, student.getAge());
            pstmt.setString(3, student.getEmail());
            pstmt.setString(4, student.getGender());
            pstmt.setString(5, student.getContactNumber());
            pstmt.setString(6, student.getCourse1());
            pstmt.setString(7, student.getCourse2());
            pstmt.setString(8, student.getCourse3());
            pstmt.setInt(9, student.getId());  // ID should be LAST for WHERE clause

            int rows = pstmt.executeUpdate();
            if (rows > 0) System.out.println("Student updated successfully!");
            else System.out.println("Student not found.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Delete student
    public void deleteStudent(int id) {
        String sql = "DELETE FROM students WHERE id = ?";
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {

            pstmt.setInt(1, id);
            int rows = pstmt.executeUpdate();
            if (rows > 0) System.out.println("Student deleted successfully!");
            else System.out.println("Student not found.");

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
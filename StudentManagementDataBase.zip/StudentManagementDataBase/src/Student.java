public class Student {
    private int id;
    private String name;
    private int age;
    private String contactNumber;
    private String course1;
    private String course2;
    private String course3;
    private String gender;
    private String email;

    // Constructor without ID (for adding new student)
    public Student(String name, int age, String email, String gender, String contactNumber,
                   String course1, String course2, String course3) {
        this.name = name;
        this.age = age;
        this.email = email;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.course1 = course1;
        this.course2 = course2;
        this.course3 = course3;
    }

    // Constructor with ID (for retrieving/updating student)
    public Student(int id, String name, int age, String email, String gender, String contactNumber,
                   String course1, String course2, String course3) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.gender = gender;
        this.contactNumber = contactNumber;
        this.course1 = course1;
        this.course2 = course2;
        this.course3 = course3;
    }

    // Getters and Setters - FIXED
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public int getAge() { return age; }
    public void setAge(int age) { this.age = age; }

    public String getGender() { return gender; }
    public void setGender(String gender) { this.gender = gender; }

    public String getContactNumber() { return contactNumber; }
    public void setContactNumber(String contactNumber) { this.contactNumber = contactNumber; }

    public String getCourse1() { return course1; }
    public void setCourse1(String course1) { this.course1 = course1; }

    public String getCourse2() { return course2; }
    public void setCourse2(String course2) { this.course2 = course2; }

    public String getCourse3() { return course3; }
    public void setCourse3(String course3) { this.course3 = course3; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    @Override
    public String toString() {
        return "Student{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", age=" + age +
                ", gender='" + gender + '\'' +
                ", contactNumber='" + contactNumber + '\'' +
                ", course1='" + course1 + '\'' +
                ", course2='" + course2 + '\'' +
                ", course3='" + course3 + '\'' +
                ", email='" + email + '\'' +
                '}';
    }
}